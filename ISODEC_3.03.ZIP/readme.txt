V. 3.03 of IsoDEC contains a the following bug fixes and improvements:
-Undocumented functions are no longer showing.
-The strain calculation in the worksheet is now more user friendly.
-Attempting to calculate bulk constants with symmetry "Isotropic" while having non-sherical grain shapes resets symmetry to "Orthorhombic".
-Right-click on the pole figure (visible only after loading an ODF) allows copying the picture to the clipboard.



