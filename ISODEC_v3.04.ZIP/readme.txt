Changelog for IsoDEC

v. 3.03 of IsoDEC contains a the following bug fixes and improvements:
1. Undocumented functions are no longer showing.
2. The strain calculation in the worksheet is now more user friendly.
3. Attempting to calculate bulk constants with symmetry "Isotropic" while having non-sherical grain shapes resets symmetry to "Orthorhombic".
4. Right-click on the pole figure (visible only after loading an ODF) allows copying the picture to the clipboard.

v 3.04
1. Option "Calc Strain". The calculation of strains/ d-spacings from known stresses was overhauled. See the manual for more information.

2. Option "Fij from stress". The calculation of diffraction elastic constants from applied stress measurements was overhauled. Each row in the worksheet needs the follwing data:
  'm h k l', phi, psi,measured d-spacings, uncertainties, d0 and uncertainties, and stress value (in column 19) at which the measurements were done. 

